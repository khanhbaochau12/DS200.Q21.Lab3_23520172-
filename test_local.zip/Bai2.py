import os
from pyspark import SparkConf, SparkContext

app_conf = SparkConf().setAppName("GenreAvgRating").setMaster("local[*]")
sc = SparkContext(conf=app_conf)
sc.setLogLevel("ERROR")

# =========================
# CHẠY LOCAL (không dùng HDFS)
# =========================
PATH_MOVIES = "movies.txt"
PATH_RATE1  = "ratings_1.txt"
PATH_RATE2  = "ratings_2.txt"

LOCAL_OUT = "output_bai2.txt"

# --- Bước 1: Tạo map movieId -> genres ---
def parse_genres(line):
    parts = line.strip().split(",")

    # tránh dòng lỗi
    if len(parts) < 3:
        return None

    movie_id = int(parts[0])
    genres = parts[2].split("|")

    return (movie_id, genres)

movie_genres = (
    sc.textFile(PATH_MOVIES)
      .map(parse_genres)
      .filter(lambda x: x is not None)
      .collectAsMap()
)

genres_bc = sc.broadcast(movie_genres)

# --- Bước 2: Expand rating theo genre ---
def expand_by_genre(line):
    cols = line.strip().split(",")

    if len(cols) < 3:
        return []

    movie_id = int(cols[1])
    rating = float(cols[2])

    genres = genres_bc.value.get(movie_id, [])

    return [(g, (rating, 1)) for g in genres]

ratings_rdd = (
    sc.textFile(f"{PATH_RATE1},{PATH_RATE2}")
      .flatMap(expand_by_genre)
)

# --- Bước 3: Tính average ---
def merge_pairs(a, b):
    return (a[0] + b[0], a[1] + b[1])

genre_stats = ratings_rdd.reduceByKey(merge_pairs)

result = (
    genre_stats
    .map(lambda x: (
        x[0],
        round(x[1][0] / x[1][1], 4),
        x[1][1]
    ))
    .sortBy(lambda x: -x[1])
    .collect()
)

# --- In kết quả ---
header = f"{'STT':<5} {'Genre':<25} {'Avg Rating':>12} {'Count':>10}"
divider = "-" * 60

print("\n" + header)
print(divider)

for idx, (genre, avg, cnt) in enumerate(result, start=1):
    print(f"{idx:<5} {genre:<25} {avg:>12.4f} {cnt:>10}")

# --- Ghi file local ---
output_lines = [header, divider]

for idx, (genre, avg, cnt) in enumerate(result, start=1):
    output_lines.append(
        f"{idx:<5} {genre:<25} {avg:>12.4f} {cnt:>10}"
    )

with open(LOCAL_OUT, "w", encoding="utf-8") as f:
    f.write("\n".join(output_lines))

print(f"\n>>> Đã lưu kết quả: {LOCAL_OUT}")

sc.stop()