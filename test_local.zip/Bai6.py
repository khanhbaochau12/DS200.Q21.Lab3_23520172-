import os
import datetime
from pyspark import SparkConf, SparkContext

app_conf = SparkConf().setAppName("YearlyAvgRating").setMaster("local[*]")
sc = SparkContext(conf=app_conf)
sc.setLogLevel("ERROR")

# ===== LOCAL FILES =====
PATH_RATE1 = "ratings_1.txt"
PATH_RATE2 = "ratings_2.txt"

LOCAL_OUT = "output_bai6.txt"

# ===== LẤY NĂM TỪ TIMESTAMP =====
def extract_year(ts_str):
    return datetime.datetime.fromtimestamp(int(ts_str)).year

# ===== RATING -> (YEAR, (RATING,1)) =====
def to_year_key(cols):

    year  = extract_year(cols[3])
    score = float(cols[2])

    return (year, (score, 1))

def merge_scores(a, b):

    return (
        a[0] + b[0],
        a[1] + b[1]
    )

rating_cols = (
    sc.textFile(f"{PATH_RATE1},{PATH_RATE2}")
      .filter(lambda line: line.strip() != "")
      .map(lambda line: line.split(","))
)

result = (
    rating_cols
    .map(to_year_key)
    .reduceByKey(merge_scores)
    .map(
        lambda r: (
            r[0],
            round(r[1][0] / r[1][1], 4),
            r[1][1]
        )
    )
    .sortBy(lambda r: r[0])
    .collect()
)

# ===== IN KẾT QUẢ =====
header = (
    f"\n  {'Năm':<8} "
    f"{'Avg Rating':>12} "
    f"{'Tổng lượt':>12}"
)

divider = "  " + "-" * 40

print(header)
print(divider)

for year, avg, cnt in result:

    print(
        f"  {year:<8} "
        f"{avg:>12.4f} "
        f"{cnt:>12}"
    )

# ===== GHI FILE LOCAL =====
output_lines = [header, divider]

for year, avg, cnt in result:

    output_lines.append(
        f"  {year:<8} "
        f"{avg:>12.4f} "
        f"{cnt:>12}"
    )

with open(LOCAL_OUT, "w", encoding="utf-8") as fout:
    fout.write("\n".join(output_lines))

print(f"\n>>> Đã lưu kết quả về local: {LOCAL_OUT}")
print("=" * 55 + "\n")

sc.stop()