import os
from pyspark import SparkConf, SparkContext

app_conf = SparkConf().setAppName("OccupationAvgRating").setMaster("local[*]")
sc = SparkContext(conf=app_conf)
sc.setLogLevel("ERROR")

# ===== LOCAL FILES =====
PATH_RATE1 = "ratings_1.txt"
PATH_RATE2 = "ratings_2.txt"
PATH_USERS = "users.txt"
PATH_OCC   = "occupation.txt"

LOCAL_OUT = "output_bai5.txt"

# ===== OCCUPATION ID -> OCCUPATION NAME =====
def parse_occupation(line):
    parts = line.strip().split(",")

    return (
        int(parts[0]),
        parts[1].strip()
    )

occ_id_to_name = (
    sc.textFile(PATH_OCC)
      .filter(lambda line: line.strip() != "")
      .map(parse_occupation)
      .collectAsMap()
)

# ===== USER ID -> OCCUPATION =====
def parse_user_occ(line):
    parts = line.strip().split(",")

    uid = int(parts[0])
    occ_id = int(parts[3])

    occ_name = occ_id_to_name.get(occ_id, "unknown")

    return (uid, occ_name)

uid_to_occ = (
    sc.textFile(PATH_USERS)
      .filter(lambda line: line.strip() != "")
      .map(parse_user_occ)
      .collectAsMap()
)

occ_bc = sc.broadcast(uid_to_occ)

# ===== RATING -> (occupation, (rating,1)) =====
def to_occ_key(cols):

    uid   = int(cols[0])
    score = float(cols[2])

    occ = occ_bc.value.get(uid, "unknown")

    return (occ, (score, 1))

def merge_scores(a, b):
    return (
        a[0] + b[0],
        a[1] + b[1]
    )

rating_cols = (
    sc.textFile(f"{PATH_RATE1},{PATH_RATE2}")
      .filter(lambda line: line.strip() != "")
      .map(lambda line: line.split(","))
)

result = (
    rating_cols
    .map(to_occ_key)
    .reduceByKey(merge_scores)
    .map(
        lambda r: (
            r[0],
            round(r[1][0] / r[1][1], 4),
            r[1][1]
        )
    )
    .sortBy(lambda r: -r[1])
    .collect()
)

# ===== IN KẾT QUẢ =====
header = (
    f"\n  {'STT':<5} "
    f"{'Occupation':<30} "
    f"{'Avg Rating':>10} "
    f"{'Số lượt':>10}"
)

divider = "  " + "-" * 65

print(header)
print(divider)

for i, (occ, avg, cnt) in enumerate(result, start=1):

    print(
        f"  {i:<5} "
        f"{occ:<30} "
        f"{avg:>10.4f} "
        f"{cnt:>10}"
    )

# ===== GHI FILE LOCAL =====
output_lines = [header, divider]

for i, (occ, avg, cnt) in enumerate(result, start=1):

    output_lines.append(
        f"  {i:<5} "
        f"{occ:<30} "
        f"{avg:>10.4f} "
        f"{cnt:>10}"
    )

with open(LOCAL_OUT, "w", encoding="utf-8") as fout:
    fout.write("\n".join(output_lines))

print(f"\n>>> Đã lưu kết quả về local: {LOCAL_OUT}")
print("=" * 65 + "\n")

sc.stop()