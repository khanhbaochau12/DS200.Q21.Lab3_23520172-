import os
from pyspark import SparkConf, SparkContext

# =========================
# Spark Config
# =========================
app_conf = SparkConf().setAppName("MovieAvgRating").setMaster("local[*]")
sc = SparkContext(conf=app_conf)
sc.setLogLevel("ERROR")

# =========================
# Local Paths
# =========================
PATH_MOVIES = "movies.txt"
PATH_RATE1  = "ratings_1.txt"
PATH_RATE2  = "ratings_2.txt"

LOCAL_OUT = "output_bai1.txt"

# =========================
# Parse Functions
# =========================
def parse_movie(line):
    parts = line.split(",")
    return (int(parts[0]), parts[1])

def parse_rating(line):
    cols = line.split(",")
    return (int(cols[1]), (float(cols[2]), 1))

# =========================
# Read Movie Titles
# =========================
id_to_title = (
    sc.textFile(PATH_MOVIES)
    .map(parse_movie)
    .collectAsMap()
)

# =========================
# Read Ratings
# =========================
ratings_rdd = (
    sc.textFile(f"{PATH_RATE1},{PATH_RATE2}")
    .map(parse_rating)
)

# =========================
# Aggregate
# =========================
def merge_counts(a, b):
    return (a[0] + b[0], a[1] + b[1])

aggregated = ratings_rdd.reduceByKey(merge_counts)

# =========================
# Compute Average
# =========================
def compute_avg(record):
    movie_id, (total, count) = record
    avg = total / count
    return (movie_id, round(avg, 4), count)

# Dataset nhỏ nên giảm threshold
qualified = (
    aggregated
    .filter(lambda r: r[1][1] >= 1)
    .map(compute_avg)
)

ranked = qualified.sortBy(lambda r: -r[1]).collect()

# =========================
# Debug
# =========================
print("Movies sample:")
print(sc.textFile(PATH_MOVIES).take(3))

print("\nRatings sample:")
print(sc.textFile(PATH_RATE1).take(3))

print("\nTotal ranked:", len(ranked))

# =========================
# Check Empty
# =========================
if len(ranked) == 0:
    print("Không có dữ liệu phù hợp.")
    sc.stop()
    exit()

# =========================
# Top Movie
# =========================
top_movie = ranked[0]
top_title = id_to_title.get(top_movie[0], "Unknown")

# =========================
# Print Result
# =========================
header = f"{'STT':<5} {'Tên phim':<40} {'Avg':>7} {'Count':>7}"
divider = "-" * 70

print("\n" + header)
print(divider)

for idx, (mid, avg, cnt) in enumerate(ranked, start=1):
    title = id_to_title.get(mid, "Unknown")
    print(f"{idx:<5} {title:<40} {avg:>7.4f} {cnt:>7}")

print("\nPhim điểm cao nhất:")
print(f"Tên phim  : {top_title}")
print(f"MovieID   : {top_movie[0]}")
print(f"Avg Rating: {top_movie[1]:.4f}")
print(f"Số lượt   : {top_movie[2]}")

# =========================
# Save Local File
# =========================
output_lines = []

output_lines.append(header)
output_lines.append(divider)

for idx, (mid, avg, cnt) in enumerate(ranked, start=1):
    title = id_to_title.get(mid, "Unknown")
    output_lines.append(
        f"{idx:<5} {title:<40} {avg:>7.4f} {cnt:>7}"
    )

output_lines.append("")
output_lines.append("Phim điểm cao nhất:")
output_lines.append(f"Tên phim  : {top_title}")
output_lines.append(f"MovieID   : {top_movie[0]}")
output_lines.append(f"Avg Rating: {top_movie[1]:.4f}")
output_lines.append(f"Số lượt   : {top_movie[2]}")

with open(LOCAL_OUT, "w", encoding="utf-8") as f:
    f.write("\n".join(output_lines))

print(f"\nĐã lưu file: {LOCAL_OUT}")

# =========================
# Stop Spark
# =========================
sc.stop()