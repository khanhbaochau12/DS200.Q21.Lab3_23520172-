import os
from collections import defaultdict
from pyspark import SparkConf, SparkContext

app_conf = SparkConf().setAppName("AgeGroupAvgRating").setMaster("local[*]")
sc = SparkContext(conf=app_conf)
sc.setLogLevel("ERROR")

# ===== LOCAL FILES =====
PATH_MOVIES = "movies.txt"
PATH_RATE1  = "ratings_1.txt"
PATH_RATE2  = "ratings_2.txt"
PATH_USERS  = "users.txt"

LOCAL_OUT = "output_bai4.txt"

AGE_GROUPS = [
    "1. Under 18",
    "2. 18-24",
    "3. 25-34",
    "4. 35-44",
    "5. 45-54",
    "6. 55+"
]

# ===== PHÂN NHÓM TUỔI =====
def classify_age(age_str):
    age = int(age_str)

    if age < 18:
        return "1. Under 18"
    elif age < 25:
        return "2. 18-24"
    elif age < 35:
        return "3. 25-34"
    elif age < 45:
        return "4. 35-44"
    elif age < 55:
        return "5. 45-54"
    else:
        return "6. 55+"

# ===== USER -> AGE GROUP =====
def parse_user_age(line):
    parts = line.strip().split(",")
    return (int(parts[0]), classify_age(parts[2]))

uid_to_group = (
    sc.textFile(PATH_USERS)
      .filter(lambda line: line.strip() != "")
      .map(parse_user_age)
      .collectAsMap()
)

group_bc = sc.broadcast(uid_to_group)

# ===== MOVIE ID -> TITLE =====
def parse_movie_title(line):
    parts = line.strip().split(",", 2)
    return (int(parts[0]), parts[1])

id_to_title = (
    sc.textFile(PATH_MOVIES)
      .filter(lambda line: line.strip() != "")
      .map(parse_movie_title)
      .collectAsMap()
)

# ===== RATING -> ((movieId, ageGroup), (rating,1)) =====
def to_age_key(cols):
    uid   = int(cols[0])
    mid   = int(cols[1])
    score = float(cols[2])

    grp = group_bc.value.get(uid, "Unknown")

    return ((mid, grp), (score, 1))

def merge_scores(a, b):
    return (a[0] + b[0], a[1] + b[1])

rating_cols = (
    sc.textFile(f"{PATH_RATE1},{PATH_RATE2}")
      .filter(lambda line: line.strip() != "")
      .map(lambda line: line.split(","))
)

raw = (
    rating_cols
    .map(to_age_key)
    .reduceByKey(merge_scores)
    .map(
        lambda r: (
            r[0][0],                      # movieId
            r[0][1],                      # age group
            round(r[1][0] / r[1][1], 4), # avg
            r[1][1]                       # count
        )
    )
    .collect()
)

# ===== ĐIỀN ĐỦ NHÓM TUỔI =====
per_movie = defaultdict(dict)

for mid, grp, avg, cnt in raw:
    per_movie[mid][grp] = (avg, cnt)

result = []

for mid in sorted(per_movie):
    for grp in AGE_GROUPS:

        if grp in per_movie[mid]:
            avg, cnt = per_movie[mid][grp]
        else:
            avg, cnt = float("nan"), 0

        result.append((mid, grp, avg, cnt))

# ===== IN KẾT QUẢ =====
header = (
    f"\n  {'MovieID':<10} "
    f"{'Tên phim':<35} "
    f"{'Nhóm tuổi':<14} "
    f"{'Avg':>7} "
    f"{'Count':>7}"
)

divider = "  " + "-" * 80

print(header)
print(divider)

for mid, grp, avg, cnt in result:

    title = id_to_title.get(mid, "Unknown")

    avg_str = f"{avg:>7.4f}" if cnt > 0 else f"{'NaN':>7}"

    print(
        f"  {mid:<10} "
        f"{title:<35} "
        f"{grp:<14} "
        f"{avg_str} "
        f"{cnt:>7}"
    )

# ===== GHI FILE LOCAL =====
output_lines = [header, divider]

for mid, grp, avg, cnt in result:

    title = id_to_title.get(mid, "Unknown")

    avg_str = f"{avg:>7.4f}" if cnt > 0 else f"{'NaN':>7}"

    output_lines.append(
        f"  {mid:<10} "
        f"{title:<35} "
        f"{grp:<14} "
        f"{avg_str} "
        f"{cnt:>7}"
    )

with open(LOCAL_OUT, "w", encoding="utf-8") as fout:
    fout.write("\n".join(output_lines))

print(f"\n>>> Đã lưu kết quả về local: {LOCAL_OUT}")
print("=" * 80 + "\n")

sc.stop()