import os
from collections import defaultdict
from pyspark import SparkConf, SparkContext

app_conf = SparkConf().setAppName("GenderAvgRating").setMaster("local[*]")
sc = SparkContext(conf=app_conf)
sc.setLogLevel("ERROR")

# =========================
# CHẠY LOCAL (không dùng HDFS)
# =========================
PATH_MOVIES = "movies.txt"
PATH_RATE1  = "ratings_1.txt"
PATH_RATE2  = "ratings_2.txt"
PATH_USERS  = "users.txt"

LOCAL_OUT = "output_bai3.txt"

# --- Bước 1: userId -> gender ---
def parse_user_gender(line):
    parts = line.strip().split(",")

    if len(parts) < 2:
        return None

    return (int(parts[0]), parts[1])

uid_to_gender = (
    sc.textFile(PATH_USERS)
      .map(parse_user_gender)
      .filter(lambda x: x is not None)
      .collectAsMap()
)

gender_bc = sc.broadcast(uid_to_gender)

# --- Bước 2: movieId -> title ---
def parse_movie_title(line):
    parts = line.strip().split(",")

    if len(parts) < 2:
        return None

    return (int(parts[0]), parts[1])

id_to_title = (
    sc.textFile(PATH_MOVIES)
      .map(parse_movie_title)
      .filter(lambda x: x is not None)
      .collectAsMap()
)

# --- Bước 3: rating -> ((movieId, gender), (rating,1)) ---
def to_gender_key(line):
    cols = line.strip().split(",")

    if len(cols) < 3:
        return None

    uid = int(cols[0])
    mid = int(cols[1])
    rating = float(cols[2])

    gender = gender_bc.value.get(uid, "Unknown")

    return ((mid, gender), (rating, 1))

ratings_rdd = (
    sc.textFile(f"{PATH_RATE1},{PATH_RATE2}")
      .map(to_gender_key)
      .filter(lambda x: x is not None)
)

# --- Bước 4: cộng tổng ---
def merge_scores(a, b):
    return (a[0] + b[0], a[1] + b[1])

aggregated = ratings_rdd.reduceByKey(merge_scores)

# --- Bước 5: tính average ---
raw = (
    aggregated
    .map(lambda x: (
        x[0][0],                         # movieId
        x[0][1],                         # gender
        round(x[1][0] / x[1][1], 4),    # avg
        x[1][1]                          # count
    ))
    .collect()
)

# --- Bước 6: nhóm theo movie ---
GENDERS = ["F", "M"]

per_movie = defaultdict(dict)

for mid, gender, avg, cnt in raw:
    per_movie[mid][gender] = (avg, cnt)

result = []

for mid in sorted(per_movie.keys()):
    for g in GENDERS:

        if g in per_movie[mid]:
            avg, cnt = per_movie[mid][g]
        else:
            avg, cnt = float("nan"), 0

        result.append((mid, g, avg, cnt))

# --- In kết quả ---
header = f"{'MovieID':<10} {'Tên phim':<40} {'Gender':<8} {'Avg':>8} {'Count':>8}"
divider = "-" * 80

print("\n" + header)
print(divider)

for mid, gender, avg, cnt in result:

    title = id_to_title.get(mid, "Unknown")

    if cnt > 0:
        avg_str = f"{avg:.4f}"
    else:
        avg_str = "NaN"

    print(
        f"{mid:<10} "
        f"{title:<40} "
        f"{gender:<8} "
        f"{avg_str:>8} "
        f"{cnt:>8}"
    )

# --- Ghi file local ---
output_lines = [header, divider]

for mid, gender, avg, cnt in result:

    title = id_to_title.get(mid, "Unknown")

    if cnt > 0:
        avg_str = f"{avg:.4f}"
    else:
        avg_str = "NaN"

    output_lines.append(
        f"{mid:<10} "
        f"{title:<40} "
        f"{gender:<8} "
        f"{avg_str:>8} "
        f"{cnt:>8}"
    )

with open(LOCAL_OUT, "w", encoding="utf-8") as f:
    f.write("\n".join(output_lines))

print(f"\n>>> Đã lưu kết quả: {LOCAL_OUT}")

sc.stop()